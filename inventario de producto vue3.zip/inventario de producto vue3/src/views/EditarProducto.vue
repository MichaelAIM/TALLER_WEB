<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { useProductosStore } from '../stores/productos';
import ImagenUpload from '../components/ImagenUpload.vue';

const router = useRouter();
const route = useRoute();
const store = useProductosStore();

const producto = ref({
  id: 0,
  nombre: '',
  descripcion: '',
  precio: 0,
  cantidad: 0,
  categoria: '',
  imagen: ''
});

onMounted(() => {
  const id = Number(route.params.id);
  const productoExistente = store.productos.find(p => p.id === id);
  if (productoExistente) {
    producto.value = { ...productoExistente };
  } else {
    router.push('/productos');
  }
});

const actualizarProducto = () => {
  store.actualizarProducto(producto.value);
  router.push('/productos');
};
</script>

<template>
  <div class="container py-4">
    <h1 class="mb-4">Editar Producto</h1>
    <div class="card">
      <div class="card-body">
        <form @submit.prevent="actualizarProducto">
          <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" class="form-control" v-model="producto.nombre" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea class="form-control" v-model="producto.descripcion" required></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Precio</label>
            <input type="number" class="form-control" v-model="producto.precio" min="0" step="0.01" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Cantidad</label>
            <input type="number" class="form-control" v-model="producto.cantidad" min="0" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Categoría</label>
            <select class="form-select" v-model="producto.categoria" required>
              <option value="">Seleccione una categoría</option>
              <option value="Electrónica">Electrónica</option>
              <option value="Ropa">Ropa</option>
              <option value="Hogar">Hogar</option>
            </select>
          </div>
          
          <ImagenUpload 
            v-model:imagen="producto.imagen"
            :imagen-actual="producto.imagen"
          />
          
          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">Actualizar</button>
            <router-link to="/productos" class="btn btn-secondary">Cancelar</router-link>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>