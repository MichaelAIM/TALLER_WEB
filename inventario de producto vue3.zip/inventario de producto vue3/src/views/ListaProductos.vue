<script setup lang="ts">
import { useProductosStore } from '../stores/productos';
import FiltrosProducto from '../components/FiltrosProducto.vue';
import QRCode from 'qrcode.vue';
import { useRouter } from 'vue-router';

const store = useProductosStore();
const router = useRouter();

const eliminarProducto = (id: number) => {
  if (confirm('¿Está seguro de eliminar este producto?')) {
    store.eliminarProducto(id);
  }
};
</script>

<template>
  <div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Inventario de Productos</h1>
      <router-link to="/productos/agregar" class="btn btn-primary">
        Agregar Producto
      </router-link>
    </div>

    <FiltrosProducto />

    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr>
            <th>ID</th>
            <th>Imagen</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Precio</th>
            <th>Cantidad</th>
            <th>Categoría</th>
            <th>QR</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="producto in store.productosFiltrados" :key="producto.id">
            <td>{{ producto.id }}</td>
            <td>
              <img 
                :src="producto.imagen || '/placeholder-product.png'" 
                alt="Imagen del producto"
                class="img-thumbnail"
                style="width: 50px; height: 50px; object-fit: cover;"
              >
            </td>
            <td>{{ producto.nombre }}</td>
            <td>{{ producto.descripcion }}</td>
            <td>${{ producto.precio.toFixed(2) }}</td>
            <td>
              <span 
                :class="producto.cantidad > 0 ? 'text-success' : 'text-danger'"
                class="fw-bold"
              >
                {{ producto.cantidad }}
              </span>
            </td>
            <td>{{ producto.categoria }}</td>
            <td>
              <QRCode 
                :value="`producto-${producto.id}`"
                :size="50"
                level="M"
                render-as="svg"
              />
            </td>
            <td>
              <div class="btn-group">
                <router-link 
                  :to="{ name: 'editar', params: { id: producto.id }}" 
                  class="btn btn-sm btn-warning"
                >
                  Editar
                </router-link>
                <button 
                  @click="eliminarProducto(producto.id)" 
                  class="btn btn-sm btn-danger"
                >
                  Eliminar
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<style scoped>
.table td {
  vertical-align: middle;
}
</style>