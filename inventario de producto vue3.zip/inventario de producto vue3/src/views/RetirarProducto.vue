<script setup lang="ts">
import { ref } from 'vue';
import { useProductosStore } from '../stores/productos';

const store = useProductosStore();

const retiro = ref({
  productoId: '',
  cantidad: 1,
  motivo: ''
});

const mensaje = ref('');
const tipoMensaje = ref('');

const retirarProducto = () => {
  const producto = store.productos.find(p => p.id === Number(retiro.value.productoId));
  
  if (!producto) {
    mensaje.value = 'Producto no encontrado';
    tipoMensaje.value = 'danger';
    return;
  }

  if (retiro.value.cantidad <= 0) {
    mensaje.value = 'La cantidad debe ser mayor a 0';
    tipoMensaje.value = 'danger';
    return;
  }

  if (retiro.value.cantidad > producto.cantidad) {
    mensaje.value = 'No hay suficiente stock disponible';
    tipoMensaje.value = 'danger';
    return;
  }

  if (store.retirarProducto(Number(retiro.value.productoId), retiro.value.cantidad, retiro.value.motivo)) {
    mensaje.value = 'Retiro realizado con éxito';
    tipoMensaje.value = 'success';
    retiro.value = {
      productoId: '',
      cantidad: 1,
      motivo: ''
    };
  } else {
    mensaje.value = 'Error al realizar el retiro';
    tipoMensaje.value = 'danger';
  }
};
</script>

<template>
  <div class="container py-4">
    <h1 class="mb-4">Retirar Productos</h1>

    <div class="row">
      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Formulario de Retiro</h5>
            
            <form @submit.prevent="retirarProducto">
              <div class="mb-3">
                <label class="form-label">Producto</label>
                <select 
                  class="form-select" 
                  v-model="retiro.productoId"
                  required
                >
                  <option value="">Seleccione un producto</option>
                  <option 
                    v-for="producto in store.productos" 
                    :key="producto.id" 
                    :value="producto.id"
                  >
                    {{ producto.nombre }} (Stock: {{ producto.cantidad }})
                  </option>
                </select>
              </div>

              <div class="mb-3">
                <label class="form-label">Cantidad a retirar</label>
                <input 
                  type="number" 
                  class="form-control" 
                  v-model="retiro.cantidad"
                  min="1"
                  required
                >
              </div>

              <div class="mb-3">
                <label class="form-label">Motivo del retiro</label>
                <textarea 
                  class="form-control" 
                  v-model="retiro.motivo"
                  required
                ></textarea>
              </div>

              <div v-if="mensaje" :class="'alert alert-' + tipoMensaje" role="alert">
                {{ mensaje }}
              </div>

              <button type="submit" class="btn btn-primary">
                Realizar Retiro
              </button>
            </form>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Historial de Retiros</h5>
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>Fecha</th>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Motivo</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="retiro in store.retiros" :key="retiro.id">
                    <td>{{ new Date(retiro.fecha).toLocaleString() }}</td>
                    <td>
                      {{ store.productos.find(p => p.id === retiro.productoId)?.nombre }}
                    </td>
                    <td>{{ retiro.cantidad }}</td>
                    <td>{{ retiro.motivo }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>