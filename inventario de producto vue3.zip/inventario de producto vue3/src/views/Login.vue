<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '../stores/auth';

const router = useRouter();
const authStore = useAuthStore();

const credenciales = ref({
  email: '',
  password: ''
});

const error = ref('');

const iniciarSesion = async () => {
  if (authStore.login(credenciales.value)) {
    router.push('/productos');
  } else {
    error.value = 'Credenciales inválidas';
  }
};
</script>

<template>
  <div class="min-vh-100 d-flex align-items-center justify-content-center bg-light">
    <div class="card shadow-sm" style="width: 100%; max-width: 400px;">
      <div class="card-body p-4">
        <h2 class="text-center mb-4">Iniciar Sesión</h2>
        
        <form @submit.prevent="iniciarSesion">
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input 
              type="email" 
              class="form-control" 
              v-model="credenciales.email"
              required
            >
          </div>
          
          <div class="mb-3">
            <label class="form-label">Contraseña</label>
            <input 
              type="password" 
              class="form-control" 
              v-model="credenciales.password"
              required
            >
          </div>

          <div v-if="error" class="alert alert-danger">
            {{ error }}
          </div>

          <button type="submit" class="btn btn-primary w-100">
            Iniciar Sesión
          </button>
        </form>
      </div>
    </div>
  </div>
</template>