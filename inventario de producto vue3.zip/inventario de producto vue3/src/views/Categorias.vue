<script setup lang="ts">
import { ref } from 'vue';
import { useCategoriasStore } from '../stores/categorias';
import type { Categoria } from '../stores/categorias';

const categoriasStore = useCategoriasStore();

const nuevaCategoria = ref({
  nombre: '',
  descripcion: ''
});

const categoriaEditar = ref<Categoria | null>(null);

const agregarCategoria = () => {
  categoriasStore.agregarCategoria(nuevaCategoria.value);
  nuevaCategoria.value = { nombre: '', descripcion: '' };
};

const iniciarEdicion = (categoria: Categoria) => {
  categoriaEditar.value = { ...categoria };
};

const guardarEdicion = () => {
  if (categoriaEditar.value) {
    categoriasStore.actualizarCategoria(categoriaEditar.value);
    categoriaEditar.value = null;
  }
};

const eliminarCategoria = (id: number) => {
  if (confirm('¿Está seguro de eliminar esta categoría?')) {
    categoriasStore.eliminarCategoria(id);
  }
};
</script>

<template>
  <div class="container py-4">
    <h1 class="mb-4">Gestión de Categorías</h1>

    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Nueva Categoría</h5>
            <form @submit.prevent="agregarCategoria">
              <div class="mb-3">
                <label class="form-label">Nombre</label>
                <input 
                  type="text" 
                  class="form-control" 
                  v-model="nuevaCategoria.nombre"
                  required
                >
              </div>
              <div class="mb-3">
                <label class="form-label">Descripción</label>
                <textarea 
                  class="form-control" 
                  v-model="nuevaCategoria.descripcion"
                  required
                ></textarea>
              </div>
              <button type="submit" class="btn btn-primary">
                Agregar Categoría
              </button>
            </form>
          </div>
        </div>
      </div>

      <div class="col-md-8">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Lista de Categorías</h5>
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="categoria in categoriasStore.categorias" :key="categoria.id">
                    <td>{{ categoria.id }}</td>
                    <td>
                      <input 
                        v-if="categoriaEditar?.id === categoria.id"
                        type="text"
                        class="form-control"
                        v-model="categoriaEditar.nombre"
                      >
                      <span v-else>{{ categoria.nombre }}</span>
                    </td>
                    <td>
                      <textarea 
                        v-if="categoriaEditar?.id === categoria.id"
                        class="form-control"
                        v-model="categoriaEditar.descripcion"
                      ></textarea>
                      <span v-else>{{ categoria.descripcion }}</span>
                    </td>
                    <td>
                      <div class="btn-group">
                        <template v-if="categoriaEditar?.id === categoria.id">
                          <button 
                            @click="guardarEdicion"
                            class="btn btn-sm btn-success"
                          >
                            Guardar
                          </button>
                          <button 
                            @click="categoriaEditar = null"
                            class="btn btn-sm btn-secondary"
                          >
                            Cancelar
                          </button>
                        </template>
                        <template v-else>
                          <button 
                            @click="iniciarEdicion(categoria)"
                            class="btn btn-sm btn-warning"
                          >
                            Editar
                          </button>
                          <button 
                            @click="eliminarCategoria(categoria.id)"
                            class="btn btn-sm btn-danger"
                          >
                            Eliminar
                          </button>
                        </template>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>