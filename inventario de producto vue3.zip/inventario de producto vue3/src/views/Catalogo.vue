<script setup lang="ts">
import { useProductosStore } from '../stores/productos';
import ProductoCard from '../components/ProductoCard.vue';
import FiltrosProducto from '../components/FiltrosProducto.vue';

const store = useProductosStore();
</script>

<template>
  <div class="container py-4">
    <h1 class="mb-4">Catálogo de Productos</h1>
    
    <FiltrosProducto />
    
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
      <div 
        v-for="producto in store.productosFiltrados" 
        :key="producto.id" 
        class="col"
      >
        <ProductoCard :producto="producto" />
      </div>
    </div>
  </div>
</template>