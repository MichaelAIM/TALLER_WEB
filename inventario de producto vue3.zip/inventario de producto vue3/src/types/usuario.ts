export interface Usuario {
  email: string;
  password: string;
}

export interface AuthState {
  usuario: Usuario | null;
  autenticado: boolean;
}