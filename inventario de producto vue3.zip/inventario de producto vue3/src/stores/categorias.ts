import { defineStore } from 'pinia';
import { ref } from 'vue';

export interface Categoria {
  id: number;
  nombre: string;
  descripcion: string;
}

export const useCategoriasStore = defineStore('categorias', () => {
  const categorias = ref<Categoria[]>([
    { id: 1, nombre: 'Electrónica', descripcion: 'Productos electrónicos y tecnología' },
    { id: 2, nombre: 'Ropa', descripcion: 'Vestimenta y accesorios' },
    { id: 3, nombre: 'Hogar', descripcion: 'Artículos para el hogar' }
  ]);

  function agregarCategoria(categoria: Omit<Categoria, 'id'>) {
    const id = categorias.value.length + 1;
    categorias.value.push({ ...categoria, id });
  }

  function actualizarCategoria(categoria: Categoria) {
    const index = categorias.value.findIndex(c => c.id === categoria.id);
    if (index !== -1) {
      categorias.value[index] = categoria;
    }
  }

  function eliminarCategoria(id: number) {
    categorias.value = categorias.value.filter(c => c.id !== id);
  }

  return {
    categorias,
    agregarCategoria,
    actualizarCategoria,
    eliminarCategoria
  };
});