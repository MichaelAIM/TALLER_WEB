import { defineStore } from 'pinia';
import { ref } from 'vue';
import type { Usuario, AuthState } from '../types/usuario';

export const useAuthStore = defineStore('auth', () => {
  const estado = ref<AuthState>({
    usuario: null,
    autenticado: false
  });

  // Demo usuarios (en producción esto vendría de una API/BD)
  const usuarios: Usuario[] = [
    { email: 'admin@ejemplo.com', password: 'admin123' }
  ];

  function login(credenciales: Usuario) {
    const usuario = usuarios.find(
      u => u.email === credenciales.email && u.password === credenciales.password
    );

    if (usuario) {
      estado.value.usuario = usuario;
      estado.value.autenticado = true;
      return true;
    }
    return false;
  }

  function logout() {
    estado.value.usuario = null;
    estado.value.autenticado = false;
  }

  return {
    estado,
    login,
    logout
  };
});