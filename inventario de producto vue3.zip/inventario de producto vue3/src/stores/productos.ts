import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import type { Producto } from '../types/producto';

export interface Retiro {
  id: number;
  productoId: number;
  cantidad: number;
  fecha: string;
  motivo: string;
}

export const useProductosStore = defineStore('productos', () => {
  const productos = ref<Producto[]>([]);
  const retiros = ref<Retiro[]>([]);
  const filtroNombre = ref('');
  const filtroCategoria = ref('');
  const precioMinimo = ref(0);
  const precioMaximo = ref(Infinity);

  const productosFiltrados = computed(() => {
    return productos.value.filter(producto => {
      const cumpleNombre = producto.nombre.toLowerCase().includes(filtroNombre.value.toLowerCase());
      const cumpleCategoria = !filtroCategoria.value || producto.categoria === filtroCategoria.value;
      const cumplePrecio = producto.precio >= precioMinimo.value && 
                          (precioMaximo.value === Infinity || producto.precio <= precioMaximo.value);
      
      return cumpleNombre && cumpleCategoria && cumplePrecio;
    });
  });

  function agregarProducto(producto: Omit<Producto, 'id'>) {
    const id = productos.value.length + 1;
    productos.value.push({ ...producto, id });
  }

  function actualizarProducto(producto: Producto) {
    const index = productos.value.findIndex(p => p.id === producto.id);
    if (index !== -1) {
      productos.value[index] = producto;
    }
  }

  function eliminarProducto(id: number) {
    productos.value = productos.value.filter(p => p.id !== id);
  }

  function retirarProducto(productoId: number, cantidad: number, motivo: string) {
    const producto = productos.value.find(p => p.id === productoId);
    if (producto && producto.cantidad >= cantidad) {
      producto.cantidad -= cantidad;
      const retiro: Retiro = {
        id: retiros.value.length + 1,
        productoId,
        cantidad,
        fecha: new Date().toISOString(),
        motivo
      };
      retiros.value.push(retiro);
      return true;
    }
    return false;
  }

  return {
    productos,
    retiros,
    filtroNombre,
    filtroCategoria,
    precioMinimo,
    precioMaximo,
    productosFiltrados,
    agregarProducto,
    actualizarProducto,
    eliminarProducto,
    retirarProducto
  };
});