<script setup lang="ts">
import NavBar from './components/NavBar.vue';
</script>

<template>
  <NavBar />
  <router-view></router-view>
</template>

<style>
#app {
  width: 100%;
  margin: 0;
  padding: 0;
}
</style>