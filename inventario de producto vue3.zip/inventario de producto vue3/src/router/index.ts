import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '../stores/auth';
import Login from '../views/Login.vue';
import ListaProductos from '../views/ListaProductos.vue';
import AgregarProducto from '../views/AgregarProducto.vue';
import EditarProducto from '../views/EditarProducto.vue';
import Categorias from '../views/Categorias.vue';
import RetirarProducto from '../views/RetirarProducto.vue';
import Catalogo from '../views/Catalogo.vue';

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'login',
      component: Login
    },
    {
      path: '/productos',
      name: 'productos',
      component: ListaProductos,
      meta: { requiresAuth: true }
    },
    {
      path: '/productos/agregar',
      name: 'agregar',
      component: AgregarProducto,
      meta: { requiresAuth: true }
    },
    {
      path: '/productos/editar/:id',
      name: 'editar',
      component: EditarProducto,
      props: true,
      meta: { requiresAuth: true }
    },
    {
      path: '/categorias',
      name: 'categorias',
      component: Categorias,
      meta: { requiresAuth: true }
    },
    {
      path: '/productos/retirar',
      name: 'retirar',
      component: RetirarProducto,
      meta: { requiresAuth: true }
    },
    {
      path: '/catalogo',
      name: 'catalogo',
      component: Catalogo,
      meta: { requiresAuth: true }
    }
  ]
});

router.beforeEach((to, from, next) => {
  const authStore = useAuthStore();
  
  if (to.meta.requiresAuth && !authStore.estado.autenticado) {
    next({ name: 'login' });
  } else {
    next();
  }
});

export default router;