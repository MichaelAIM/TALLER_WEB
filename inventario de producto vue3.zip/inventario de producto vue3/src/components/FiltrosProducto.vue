<script setup lang="ts">
import { useProductosStore } from '../stores/productos';

const store = useProductosStore();
</script>

<template>
  <div class="card mb-4">
    <div class="card-body">
      <h5 class="card-title">Filtros</h5>
      <div class="row g-3">
        <div class="col-md-3">
          <label class="form-label">Nombre</label>
          <input
            type="text"
            class="form-control"
            v-model="store.filtroNombre"
            placeholder="Buscar por nombre..."
          >
        </div>
        <div class="col-md-3">
          <label class="form-label">Categoría</label>
          <select class="form-select" v-model="store.filtroCategoria">
            <option value="">Todas</option>
            <option value="Electrónica">Electrónica</option>
            <option value="Ropa">Ropa</option>
            <option value="Hogar">Hogar</option>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">Precio Mínimo</label>
          <input
            type="number"
            class="form-control"
            v-model="store.precioMinimo"
            min="0"
          >
        </div>
        <div class="col-md-3">
          <label class="form-label">Precio Máximo</label>
          <input
            type="number"
            class="form-control"
            v-model="store.precioMaximo"
            min="0"
          >
        </div>
      </div>
    </div>
  </div>
</template>