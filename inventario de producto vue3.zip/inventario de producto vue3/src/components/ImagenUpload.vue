<script setup lang="ts">
import { ref } from 'vue';

const props = defineProps<{
  imagenActual?: string;
}>();

const emit = defineEmits<{
  (e: 'update:imagen', value: string): void;
}>();

const previewImage = ref(props.imagenActual || '');

const handleImageUpload = (event: Event) => {
  const input = event.target as HTMLInputElement;
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      previewImage.value = result;
      emit('update:imagen', result);
    };
    reader.readAsDataURL(input.files[0]);
  }
};
</script>

<template>
  <div class="mb-3">
    <label class="form-label">Imagen del Producto</label>
    <input 
      type="file" 
      class="form-control" 
      accept="image/*"
      @change="handleImageUpload"
    >
    <div v-if="previewImage" class="mt-2">
      <img 
        :src="previewImage" 
        alt="Vista previa" 
        class="img-thumbnail"
        style="max-height: 200px"
      >
    </div>
  </div>
</template>