<script setup lang="ts">
import { computed } from 'vue';
import QRCode from 'qrcode.vue';
import type { Producto } from '../types/producto';

const props = defineProps<{
  producto: Producto;
}>();

const qrValue = computed(() => `producto-${props.producto.id}`);
</script>

<template>
  <div class="card h-100">
    <img 
      :src="producto.imagen || '/placeholder-product.png'" 
      class="card-img-top"
      alt="Imagen del producto"
      style="height: 200px; object-fit: cover;"
    >
    <div class="card-body">
      <h5 class="card-title">{{ producto.nombre }}</h5>
      <p class="card-text">{{ producto.descripcion }}</p>
      <p class="card-text">
        <small class="text-muted">Categoría: {{ producto.categoria }}</small>
      </p>
      <p class="card-text fw-bold">${{ producto.precio.toFixed(2) }}</p>
      <p class="card-text" :class="producto.cantidad > 0 ? 'text-success' : 'text-danger'">
        {{ producto.cantidad > 0 ? 'En stock' : 'Sin stock' }}
      </p>
    </div>
    <div class="card-footer bg-white text-center">
      <QRCode 
        :value="qrValue"
        :size="100"
        level="M"
        render-as="svg"
      />
    </div>
  </div>
</template>