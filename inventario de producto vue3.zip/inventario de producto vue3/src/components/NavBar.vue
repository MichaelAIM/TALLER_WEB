<script setup lang="ts">
import { useRouter } from 'vue-router';
import { useAuthStore } from '../stores/auth';

const router = useRouter();
const authStore = useAuthStore();

const cerrarSesion = () => {
  authStore.logout();
  router.push('/');
};
</script>

<template>
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4" v-if="authStore.estado.autenticado">
    <div class="container">
      <span class="navbar-brand">Sistema de Inventario</span>
      
      <button 
        class="navbar-toggler" 
        type="button" 
        data-bs-toggle="collapse" 
        data-bs-target="#navbarNav"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <router-link class="nav-link" to="/productos">Productos</router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/catalogo">Catálogo</router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/categorias">Categorías</router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/productos/retirar">Retirar Productos</router-link>
          </li>
        </ul>
        
        <div class="d-flex">
          <span class="navbar-text me-3">
            {{ authStore.estado.usuario?.email }}
          </span>
          <button @click="cerrarSesion" class="btn btn-light">
            Cerrar Sesión
          </button>
        </div>
      </div>
    </div>
  </nav>
</template>